package com.deepak.quizservice.service;

import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deepak.quizservice.doa.QuizDao;
import com.deepak.quizservice.feign.QuizInterface;
// import com.deepak.quizservice.doa.QuizDao;
// import com.deepak.quizservice.models.Question;
import com.deepak.quizservice.models.QuestionWrapper;
import com.deepak.quizservice.models.Quiz;
// import com.deepak.quizservice.models.Quiz;
import com.deepak.quizservice.models.Response;

// import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
// import java.util.Optional;

@Service
public class QuizService {

    @Autowired
    private QuizDao quizDoa;

    @Autowired
    private QuizInterface quizInterface;
    // @Autowired
    // private QuestionDao questionDao;

    public ResponseEntity<String> createQuiz(String category, int noOfQuestions, String quizTitle) {
        List<Integer> questionIds = quizInterface.getQuestionsForQuiz(category, noOfQuestions).getBody();
        Quiz quiz = new Quiz();
        quiz.setTitle(quizTitle);
        quiz.setQuestionIds(questionIds);
        quizDoa.save(quiz);
        return new ResponseEntity<>("Quiz creation sucessfull", HttpStatus.CREATED);
    }

    public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(int id) {
        Optional<Quiz> quiz = quizDoa.findById(id);
        List<Integer> questionIds = quiz.get().getQuestionIds();
        List<QuestionWrapper> questionsForUser = quizInterface.getQuestionsByIds(questionIds).getBody();
        return new ResponseEntity<>(questionsForUser, HttpStatus.OK);
    }

    public ResponseEntity<Integer> calculateScore(int id, List<Response> responses) {
        Integer score = quizInterface.getScore(responses).getBody();
        return new ResponseEntity<>(score, HttpStatus.OK);
    }
}

