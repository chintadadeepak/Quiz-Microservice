package com.deepak.quizservice.doa;

// import com.deepak.QuizApp.models.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

import com.deepak.quizservice.models.Quiz;

public interface QuizDao extends JpaRepository<Quiz, Integer> {

}
